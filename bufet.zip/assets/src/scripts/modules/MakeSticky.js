import Sticky from 'sticky-js';

class MakeSticky {
  constructor(){
    var sticky = new Sticky('.js-sticky');
  }
}

export default MakeSticky;